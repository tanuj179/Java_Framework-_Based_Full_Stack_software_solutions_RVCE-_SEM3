package lab6;



	import java.util.Scanner;
	import org.springframework.context.ApplicationContext;
	import org.springframework.context.annotation.AnnotationConfigApplicationContext;
	import org.springframework.context.annotation.Configuration;

	@Configuration
	public class mainexe {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			ApplicationContext context1=new AnnotationConfigApplicationContext(Config.class);
			ApplicationContext context2=new AnnotationConfigApplicationContext(Config.class);

			Student s=(Student)context1.getBean(Student.class);

			Student1 s1=(Student1)context1.getBean(Student1.class);
			

			String name,course,college;
			int age,ch;
			float marks;
			Scanner sc=new Scanner(System.in);
			System.out.println("Welcome Student");
			while(true) {
				System.out.println("\n1)Start\t\t2)Exit");
				ch=sc.nextInt();
				if(ch==1) {
						System.out.println("Enter Name :");
						name=sc.next();
						System.out.println("Enter Age :");
						age=sc.nextInt();
						System.out.println("Enter Course :");
						course=sc.next();
						System.out.println("Enter College :");
						college=sc.next();
						System.out.println("Enter Marks:");
						marks=sc.nextFloat();
						s.setAge(age);
						s.setName(name);
						s1.setCollege(college);
						s1.setCourse(course);
						s1.setMarks(marks);
						s.setS1(s1);
						System.out.println(s);
					}
				else if(ch==2) {
						break;
					}
			}
			System.out.println("------------Thank You------------");
			}
		}



