package lab6;

import java.io.Serializable;

public class Student implements Serializable{
	private static final long serialVersionUID=1L;
	private String name;
	private int age;
	Student1 s1;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Student1 getS1() {
		return s1;
	}
	public void setS1(Student1 s1) {
		this.s1 = s1;
	}
	public String toString() {
		return "Name : \t"+name+
				"Age : \t"+age+
				s1;
	}
}
