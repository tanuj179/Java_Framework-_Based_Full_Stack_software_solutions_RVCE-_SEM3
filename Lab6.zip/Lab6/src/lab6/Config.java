package lab6;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class Config {
////	This is a Java code that uses Spring Framework's annotations 
//	to create and configure beans. The code defines a class
//	called "Config" and annotates it with the "@Configuration" 
//	annotation which tells Spring that this class contains methods 
//	that define beans.
////
////	There are two methods in this class, "setBeanStudent" 
//	and "setBeanStudent1", both of which are annotated with 
//	"@Bean". This annotation tells Spring that the methods will
//	be used to create and return beans.
////
////	The "setBeanStudent" method uses the "@Scope" annotation 
//	with the value "ConfigurableBeanFactory.SCOPE_SINGLETON"
//	which tells Spring to create a single instance of the bean 
//	and reuse it for all requests.
////
////	The "setBeanStudent1" method also uses the "@Scope"
//	annotation with the value "ConfigurableBeanFactory."
//	"SCOPE_PROTOTYPE" which tells Spring to create 
//	a new instance of the bean every time it is requested.
////
////	Overall, this code is used to configure two 
//	beans of class "Student" and "Student1" with 
//	different scoping, which will be used in the application.
	@Bean
	@Scope(value=ConfigurableBeanFactory.SCOPE_SINGLETON)
	public Student setBeanStudent() {
		return new Student();
	}
	@Bean
	@Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public Student1 setBeanStudent1() {
		return new Student1();
	}
	
	
}
