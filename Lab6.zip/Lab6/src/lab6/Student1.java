package lab6;

import java.io.Serializable;

public class Student1 implements Serializable {
	private static final long serialVersionUID=1L;
	private String course,college;
	private float marks;
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	public String toString() {
		return "Course : \t"+course+
				"College  \t"+college+
				"Marks : \t"+marks;
	}
}
