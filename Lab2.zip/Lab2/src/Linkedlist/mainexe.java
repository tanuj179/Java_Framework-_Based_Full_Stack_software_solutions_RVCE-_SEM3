package Linkedlist;
import java.util.*;
public class mainexe {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Student s1=null;
		ArrayList<Student> l1=new ArrayList<Student>();
		while(true) {
			System.out.println("1.Insert");
			System.out.println("2.Update");
			System.out.println("3.Remove");
			System.out.println("4.Display");
			System.out.println("5.Sort");
			System.out.println("6.Clear");
			System.out.println("7.Size");
			System.out.println("Enter the choice");
			int choice=sc.nextInt();
			if(choice==1)
			{
				System.out.println("Enter the usn");
				int usn=sc.nextInt();
				System.out.println("Enter the name");
				String name=sc.next();
				System.out.println("Enter the address");
				String add=sc.next();
				s1=new Student(usn,name,add);
				l1.add(s1);
			}
			else if(choice==2) {
				System.out.println("Enter the index value");
				int index=sc.nextInt();

				System.out.println("Enter the usn");
				int usn=sc.nextInt();
				System.out.println("Enter the name");
				String name=sc.next();
				System.out.println("Enter the address");
				String add=sc.next();
				s1=new Student(usn,name,add);
				l1.set(index, s1);
				
			}
			else if(choice==3) {
				System.out.println("Enter the index value");
				int index=sc.nextInt();
				l1.remove(index);
			}
			else if(choice==4) {
				s1.display(l1);
			}
			else if(choice==5) {
				//Collections.sort(l1);
				s1.display(l1);
				
			}
			else if(choice==6) {
				l1.clear();
			}
			else if(choice==7) {
				
				int size=l1.size();
				System.out.println("Size of arraylist "+size);
			}
			else {
				break;
			}
		}
	}

}
