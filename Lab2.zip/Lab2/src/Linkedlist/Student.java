package Linkedlist;
import java.util.*;
public class Student {
	int usn;
	String name,add;
	
	public Student(int usn,String name,String add) {
		this.usn=usn;
		this.name=name;
		this.add=add;
		
		
	}
	public void display(List<Student> l) {
		Iterator<Student> i=l.iterator();
		while(i.hasNext()) {
			Student s=i.next();
			System.out.println("Usn : "+s.usn);
			System.out.println("Name : "+s.name);
			System.out.println("Address : "+s.add);

		}
	}
}
