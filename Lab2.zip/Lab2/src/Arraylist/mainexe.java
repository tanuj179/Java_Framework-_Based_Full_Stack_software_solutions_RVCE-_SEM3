package Arraylist;
import java.util.*;
public class mainexe {

	public static <T> void main(String[] args) {
		Scanner sc=new Scanner(System.in) ;
		Student s1=null;
		LinkedList<Student> l1=new LinkedList<Student>();
		while(true) {
			System.out.println("1.Insert");
			System.out.println("2.Display");
			System.out.println("3.Update.");
			System.out.println("4.Delete");
			System.out.println("5.Size");
			System.out.println("6.Clear");
			System.out.println("7.Sort");
			System.out.println("8.AddFirst");
			System.out.println("9.AddLAst");
			System.out.println("10.removefirst");
			System.out.println("11.removelast");
			System.out.println("Enter the choice");
			System.out.println("-----------------");
			int choice=sc.nextInt();
			
			if(choice==1) {
				//Insert 
				System.out.println(" enter the usn");
				int usn=sc.nextInt();
				System.out.println("enter the name");
				String name=sc.next();
				System.out.println("enter the add");
				String add=sc.next();
				s1=new Student(usn,name,add);
				l1.add(s1);
				System.out.println("Added");
				System.out.println("---------------");
			}
			else if(choice==2) {
				s1.display(l1);
				System.out.println("---------------");
			}
			else if(choice==3) {
				System.out.println("Enter the index value to update");
				int index=sc.nextInt();
				System.out.println(" enter the usn");
				int usn=sc.nextInt();
				System.out.println("enter the name");
				String name=sc.next();
				System.out.println("enter the add");
				String add=sc.next();
				s1=new Student(usn,name,add);
				l1.set(index, s1);
				System.out.println("Updated");
				System.out.println("---------------");
			}
			else if(choice==4) {
				System.out.println("Enter the index value to update");
				int index=sc.nextInt();
				l1.remove(index);
			}
			else if(choice==5) {
				int size=l1.size();
				System.out.println("Size of Linked List"+size);
			}
			else if(choice==6) {
				l1.clear();
			}
			else if(choice==7) {
				//Collections.sort(l1);
				//s1.display(l1);
				
			}
			else if(choice==8) {
				System.out.println(" enter the usn");
				int usn=sc.nextInt();
				System.out.println("enter the name");
				String name=sc.next();
				System.out.println("enter the add");
				String add=sc.next();
				s1=new Student(usn,name,add);
				l1.addFirst(s1);
				System.out.println("Added");
				System.out.println("---------------");
			}	
			else if(choice==9) {
				System.out.println(" enter the usn");
				int usn=sc.nextInt();
				System.out.println("enter the name");
				String name=sc.next();
				System.out.println("enter the add");
				String add=sc.next();
				s1=new Student(usn,name,add);
				l1.addLast(s1);
				System.out.println("Added");
				System.out.println("---------------");
			}
			else if(choice==10) {
				l1.removeFirst();
			}
			else if(choice==11) {
				l1.removeLast();
			}
			else {
				break;
			}
		}
	}

}
