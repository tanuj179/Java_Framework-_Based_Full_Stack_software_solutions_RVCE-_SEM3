package lab5;

import java.io.Serializable;

public class Ticket implements Serializable {
	
	private static final long serialVersionUID=1L;
	int ticketnumber;
	String description;
	public int getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(int ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "\n Ticket Number : \t"+ticketnumber+
				"\n Description : \t"+description;
	}

}
