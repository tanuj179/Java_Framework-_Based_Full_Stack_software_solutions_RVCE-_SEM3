package lab5;
import java.util.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class mainexecute {

	public static void main(String[] args) {
		ApplicationContext context1= new ClassPathXmlApplicationContext("bean.xml");
		ApplicationContext context2= new ClassPathXmlApplicationContext("bean.xml");
		
		Customer cc=(Customer)context1.getBean("cbean");
		Ticket tt=(Ticket)context2.getBean("tbean");
		int ticketnumber,ch=0;
		String description;
		String name,address,email;
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome Passeneger\n\n");
		
		while(true) {
			System.out.println("1)Start\t\t2)Exit");
			ch=sc.nextInt();
			if(ch==1) {
					System.out.println("Enter Name :");
					name=sc.next();
					System.out.println("Enter email :");
					email=sc.next();
					System.out.println("Enter address :");
					address=sc.next();
					System.out.println("Enter Ticket number :");
					ticketnumber=sc.nextInt();
					System.out.println("Enter description :");
					description=sc.next();
					cc.setName(name);
					cc.setEmail(email);
					cc.setAddress(address);
					tt.setTicketnumber(ticketnumber);
					tt.setDescription(description);
					cc.setT2(tt);
					System.out.println(cc);
					
					
				}
			else if(ch==2) {
					break;
				}
		
	}
	}
}
