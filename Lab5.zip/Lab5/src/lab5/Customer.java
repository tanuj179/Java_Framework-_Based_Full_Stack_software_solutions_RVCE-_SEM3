package lab5;

import java.io.Serializable;

public class Customer implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1822887442090794827L;
	//public static final long serialVersionUId =1L;
	private String name,address,email;
	private Ticket T2;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Ticket getT2() {
		return T2;
	}
	public void setT2(Ticket t2) {
		T2 = t2;
	}
	@Override
	public String toString() {
		return "Name : \t"+name +
				"Address : \t"+address+
				"email : \t"+email+T2;
				
	}
	
	
}
